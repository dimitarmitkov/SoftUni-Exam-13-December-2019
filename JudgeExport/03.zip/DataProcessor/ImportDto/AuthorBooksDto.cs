﻿namespace BookShop.DataProcessor.ImportDto
{
    public class AuthorBooksDto
    {
        public int? Id { get; set; }
    }
}